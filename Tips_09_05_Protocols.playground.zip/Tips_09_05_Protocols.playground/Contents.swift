//
//  A Demo for iOS Development Tips Weekly
//  by Steven Lipton (C)2020, All rights reserved
// Check out the video series on LinkedIn learning at https://linkedin-learning.pxf.io/YxZgj
//  For code go to http://bit.ly/AppPieGithub

//:#Protocol Demo
//: Learn what a protocol is and what you can do with them. 
protocol Pizza{
    var length:Double{ get }
    var width:Double { get set }
    var toppings:[String]{get set}
    func area()->Double
    init(length:Double,width:Double)
}

extension Pizza{

}

class RectanglePizza{

}


struct RoundPizza{
    
}

//: Test Area
let a = RectanglePizza()
let b = RoundPizza()

